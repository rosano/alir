# Licences

## Chair icon


Artist: [Robin Weatherall](http://www.robinweatherall.eu/icons/) [@robinweatherall](https://twitter.com/robinweatherall)

Iconset: Library Icons

License: Freeware

Source: [IconArchive](http://www.iconarchive.com/show/library-icons-by-skuzigraphic/chair-icon.html)
